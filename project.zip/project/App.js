const salebtn = document.getElementById('btnview');

salebtn.addEventListener("click" , function(){
    location.href = "https://google.com";
})


function responsivemenu(){
    var icon = document.getElementById("togglemenu");
    if(icon.className === "menu-item"){
        icon.className += " responsive";
    } else {
        icon.className = "menu-item";
    }
}